from app import redis_client

# print_all_template = "目前傭有的設備有:\n門口警示\n客廳\溫溼度\n客廳\電燈開關1\n        \電燈開關2\n廚房\瓦斯偵測"
