from .. import db


class Response(db.Model):
    __tablename__ = 'response'
    id = db.Column(db.Integer, primary_key=True)
    get = db.Column(db.String(80), nullable=False)
    response = db.Column(db.String(150), nullable=False)
    type = db.Column(db.Integer, nullable=False)
    # 0: text, 1: image, 2: video, 3: audio, 4: location, 5: sticker, 6: imagemap, 7: template
    # 99:temperture 98:huminity

    def __init__(self, get, response, type):
        self.get = get
        self.response = response
        self.type = type


class MQTTdevice(db.Model):
    __tablename__ = 'mqttdevice'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), nullable=False)
    topic = db.Column(db.String(80), nullable=False)
    type = db.Column(db.Integer, nullable=False)
    # 0:switch 1:num

    def __init__(self, name, topic, type):
        self.name = name
        self.topic = topic
        self.type = type
